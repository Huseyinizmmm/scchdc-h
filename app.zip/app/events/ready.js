const chalk = require("chalk");
const moment = require("moment");
const Discord = require("discord.js");
const ayarlar = require("../ayarlar.json");
var prefix = ayarlar.prefix;

module.exports = client => {
  setInterval(function() {}, 8000);
  var msgArray = ["❄️ | i!yardım ", "🚀 İSYAN BOT 7/24 HİZMETİNİZDE 🚀"];

  setInterval(() => {
    var rastgeleOyun = Math.floor(Math.random() * msgArray.length);
    client.user.setActivity(`${msgArray[rastgeleOyun]}`, {
      type: "PLAYİNG"
    });
  }, 5000);
  console.log(`İSYAN BOT başarıyla giriş yaptı.`);
};
