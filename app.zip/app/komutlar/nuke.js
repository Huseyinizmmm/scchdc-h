const Discord = require("discord.js");

exports.run = (client, message, args) => {
  if (!message.member.hasPermission("MANAGE_CHANNELS"))
    return message.channel.send(
      "Bu Komutu Kullanabilmek İçin **KANALLARI YÖNET** Yetkisine Sahip Olman Gerek."
    );

  message.channel.clone().then(knl => {
    let position = message.channel.position;

    knl.setPosition(position);

    message.channel.delete();

    const embed = new Discord.messageEmbed()

      .setTitle("Kanal Patladı!")

      .setImage("https://media1.giphy.com/media/oe33xf3B50fsc/giphy.gif")

      .setFooter(`Nuke Atan: ${message.author.name}`);

    knl.send(embed);
  });
};

exports.conf = {
  enabled: true,

  guildOnly: true,

  aliases: ["nuke"],

  kategori: "Moderasyon"
};

exports.help = {
  name: "nuke",

  description: "belirtilen kanalı siler tekrar oluşturur.",

  usage: "nuke"
};
