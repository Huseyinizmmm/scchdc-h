const Discord = require("discord.js");
const client = new Discord.Client();
const db = require("quick.db");
exports.run = (client, message, args, member) => {
  const yardım = new Discord.MessageEmbed()
    .setAuthor(` İSYAN BOT Yardım Menusü`, client.user.avatarURL())
    .setColor("0x36393F")
    .setThumbnail(client.user.avatarURL())
    .setDescription(
      `• Hey! <@${
        message.author.id
      }> beni kullandığın için teşekkür ederim!\n •  Prefixim: **i!**\n • Dilim: **TR** :flag_tr:\n • Üyelik durumu: ${
        db.has(`üyelikk_${message.author.id}`, "üyelik")
          ? `**Gold üye!**`
          : `**Normal üye!**`
      }`
    )
    .addField(
      " • Kategoriler:",
      `> • [!kullanıcı](kullanıcı): **Kullanıcı yardım menüsünü gösterir.**\n > • [!moderasyon](moderasyon): **Moderasyon yardım menüsünü gösterir.**\n > • [!kayıtsistemi](kayıtsistemi): ** Kayıt sistemi yardım menüsünü gösterir.**\n > • [!korumasistemi](korumasistemi): ** Koruma sistemi yardım menüsünü gösterir.**\n > • [!logosistemi](logosistemi): ** Logo sistemi yardım menüsünü gösterir.**\n > • [!çekilişsistemi](çekilişsistemi): ** Çekiliş sistemi yardım menüsünü gösterir.**`
    )
    .addField(
      " • Güncelleme Notları:",
      "**Güncelleme v0.4:** Çekiliş sistemi eklendi!"
    )

    .addField(
      " • Linkler:",
      "• [Davet Et](https://discord.com/oauth2/authorize?client_id=892401590932226058&scope=bot&permissions=8) • [Destek Sunucusu](https://discord.gg/R23juR6zpT) • [Web Site](https://dcbotlar.xyz) •"
    )
    .setImage("")
    .setFooter("İSYAN BOT", message.author.avatarURL())
    .setTimestamp();
  message.channel.send(yardım);
};
exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ["y", "help", "h"],
  permLevel: 0
};

exports.help = {
  name: "yardım",
  description: "westra",
  usage: "westra"
};
