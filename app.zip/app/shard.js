const Discord = require("discord.js");
const ewing2 = require("./ayarlar.json");
const bot = new Discord.Client();
const ewing = new Discord.ShardingManager("./ewing.js", {
  totalShards: 1,
  token: ewing2.token
});

ewing.spawn();

ewing.on("launch", shard => {
  console.log(`**${shard.id}** ID'li shard başlatıldı.`);
});

setTimeout(() => {
  ewing.broadcastEval("process.exit()");
}, 21600000);
